package GUI;

import Classes.Empresa;
import Classes.Mensagem;
import Classes.Projeto;
import Classes.Usuario;
import DAO.EmpresaDAO;
import DAO.MensagemDAO;
import DAO.ProjetoDAO;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public final class PerfilProjetoAlternativo extends javax.swing.JFrame {

    private Projeto projeto;
    private boolean changer = false;
    boolean empresaNova = false;
    private Usuario usuario;
    private Usuario backToUserProfile;
    
    
    
    public void changeToEditable (javax.swing.JTextField jElement, boolean condition){
        if (condition) {
            jElement.setBackground(Color.white);
            jElement.setForeground(Color.black);
            jElement.setBorder(BorderFactory.createLineBorder(Color.white));
            jElement.setEditable(true);
        } else {
            jElement.setBackground(new Color(255, 102, 0));
            jElement.setForeground(Color.white);
            jElement.setBorder(BorderFactory.createEmptyBorder());
            jElement.setEditable(false);
        }    
    }
    public void enable(boolean condition, javax.swing.JComboBox jComboBox, javax.swing.JTextField jTextField) throws SQLException{
        if (condition){
            java.awt.Point location = jTextField.getLocation();
            jTextField.setVisible(false);
            jComboBox.setVisible(true);
            jComboBox.setLocation(location);
            addEmpresas(jComboBox);
            Empresa empresa = projeto.getEmpresa();
            jComboBox.setSelectedItem(empresa);
            jComboBox.setForeground(Color.black);
            jComboBox.setBackground(Color.white);
        }
    }
    
    private void addEmpresas(javax.swing.JComboBox jComboBox) throws SQLException {
        for (Empresa e: new EmpresaDAO().read()){
            jComboBox.addItem(e);
        }
    }
    
    public void readJTableParticipantes(Projeto projeto) throws SQLException{
        DefaultTableModel modelo = (DefaultTableModel) jTable3.getModel();
        
        modelo.setNumRows(0);
        
        ProjetoDAO projetoDao = new ProjetoDAO();
        
        for(Usuario u: projetoDao.readUsers(projeto)){
            modelo.addRow(new Object[]{
                u.getTipoString(),
                u
            });
        }
    }
    
    public void readJTableMensagens(Projeto projeto) throws SQLException{
        DefaultTableModel modelo = (DefaultTableModel) jTable2.getModel();
        
        modelo.setNumRows(0);

        for(Mensagem m: new MensagemDAO().filterByProject(projeto)){
            modelo.addRow(new Object[]{
                m,
                m.getRemetente().getNome(),
                m.getData(),
                //dia retorna d/m/aaaa invés de dd/mm/aaaa quando dia ou mês < 10
                m.getHora()
                //hora retorna errado
            });
        }
    }
    
    private void userMode () {
        editar.setVisible(false);
        remover.setVisible(false);
        novoParticipante.setVisible(false);
        cadastrarMensagemSuper.setVisible(false);
        jMenu4.setVisible(false);
    }
    
    public PerfilProjetoAlternativo() {
        initComponents();
        jComboBox1.setVisible(false);
        jComboBox1.setSelectedItem(this.projeto.getEmpresa());
        jCheckBox1.setVisible(false);
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
    }
    
    public PerfilProjetoAlternativo(Projeto projeto) throws SQLException {
        initComponents();
        this.projeto = projeto;
        readJTableParticipantes(projeto);
        readJTableMensagens(projeto);
        getNome.setText(projeto.getNome());
        getEmpresa.setText(projeto.getEmpresa().getNome());
        jComboBox1.setSelectedItem(projeto.getEmpresa());
        jComboBox1.setVisible(false);
        jCheckBox1.setVisible(false);
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
    }
    
    public PerfilProjetoAlternativo(Projeto projeto, Usuario usuario, Usuario usuarioProfile) throws SQLException {
        initComponents();
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        this.usuario = usuario;
        this.projeto = projeto;
        this.backToUserProfile = usuarioProfile;
        readJTableParticipantes(projeto);
        readJTableMensagens(projeto);
        getNome.setText(projeto.getNome());
        getEmpresa.setText(projeto.getEmpresa().getNome());
        jComboBox1.setVisible(false);
        jCheckBox1.setVisible(false);
        if (usuario.getTipo() < 2) {
            userMode();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ImageIcon icon = new ImageIcon(getClass().getResource("background.png"));
        Image image = icon.getImage();
        jDesktopPane1 = new javax.swing.JDesktopPane(){
            public void paintComponent(Graphics g){
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        remover = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        getNome = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jCheckBox1 = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        getEmpresa = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        novoParticipante = new javax.swing.JButton();
        atualizarParticipantes = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        cadastrarMensagemSuper = new javax.swing.JButton();
        jMenuBar5 = new javax.swing.JMenuBar();
        jMenu14 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        menuConsultar = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        menuCadastrar = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenu10 = new javax.swing.JMenu();
        jMenuItem15 = new javax.swing.JMenuItem();
        jMenuItem16 = new javax.swing.JMenuItem();
        jMenuItem17 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jButton2.setBackground(new java.awt.Color(255, 102, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Voltar");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 102, 0));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N

        remover.setBackground(new java.awt.Color(255, 255, 255));
        remover.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        remover.setForeground(new java.awt.Color(255, 102, 0));
        remover.setText("Remover");
        remover.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        remover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerActionPerformed(evt);
            }
        });

        editar.setBackground(new java.awt.Color(255, 255, 255));
        editar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        editar.setForeground(new java.awt.Color(255, 102, 0));
        editar.setText("Editar");
        editar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });

        getNome.setEditable(false);
        getNome.setBackground(new java.awt.Color(255, 102, 0));
        getNome.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        getNome.setForeground(new java.awt.Color(255, 255, 255));
        getNome.setText("getNome");
        getNome.setBorder(null);
        getNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getNomeActionPerformed(evt);
            }
        });

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jCheckBox1.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jCheckBox1.setText("Nova Empresa");
        jCheckBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox1ItemStateChanged(evt);
            }
        });
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Empresa:");

        getEmpresa.setEditable(false);
        getEmpresa.setBackground(new java.awt.Color(255, 102, 0));
        getEmpresa.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        getEmpresa.setForeground(new java.awt.Color(255, 255, 255));
        getEmpresa.setText("getNome");
        getEmpresa.setBorder(null);
        getEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getEmpresaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(getNome)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jCheckBox1))
                            .addComponent(getEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 675, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(remover)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editar, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(editar)
                        .addComponent(remover))
                    .addComponent(getNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jCheckBox1))
                .addGap(2, 2, 2)
                .addComponent(getEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Titulo", "Remetente", "Data", "Hora"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jLabel15.setFont(new java.awt.Font("Arial Black", 0, 20)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setText("Últimas mensagens:");

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 102, 0));
        jButton4.setText("Nova mensagem");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel16.setText("Participantes:");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tipo", "Nome"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        novoParticipante.setBackground(new java.awt.Color(255, 255, 255));
        novoParticipante.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        novoParticipante.setForeground(new java.awt.Color(255, 102, 0));
        novoParticipante.setText("Novo participante");
        novoParticipante.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        novoParticipante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                novoParticipanteActionPerformed(evt);
            }
        });

        atualizarParticipantes.setBackground(new java.awt.Color(255, 255, 255));
        atualizarParticipantes.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        atualizarParticipantes.setForeground(new java.awt.Color(255, 102, 0));
        atualizarParticipantes.setText("Atualizar");
        atualizarParticipantes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        atualizarParticipantes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarParticipantesActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(255, 255, 255));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 102, 0));
        jButton7.setText("Atualizar");
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        cadastrarMensagemSuper.setBackground(new java.awt.Color(255, 255, 255));
        cadastrarMensagemSuper.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cadastrarMensagemSuper.setForeground(new java.awt.Color(255, 102, 0));
        cadastrarMensagemSuper.setText("Cadastrar mensagem de usuário...");
        cadastrarMensagemSuper.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cadastrarMensagemSuper.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarMensagemSuperActionPerformed(evt);
            }
        });

        jDesktopPane1.setLayer(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jPanel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jLabel15, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jButton4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jLabel16, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jScrollPane3, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(novoParticipante, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(atualizarParticipantes, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jButton7, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(cadastrarMensagemSuper, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(novoParticipante, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(atualizarParticipantes)))
                .addGap(6, 6, 6)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cadastrarMensagemSuper)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton7))
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(novoParticipante)
                    .addComponent(atualizarParticipantes)
                    .addComponent(jLabel15)
                    .addComponent(jButton4)
                    .addComponent(jButton7)
                    .addComponent(cadastrarMensagemSuper))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        jMenu14.setText("Home");
        jMenu14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu14MouseClicked(evt);
            }
        });
        jMenuBar5.add(jMenu14);

        jMenu4.setText("Menu");

        menuConsultar.setText("Consultar...");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem1.setText("Projetos");
        jMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem1MouseClicked(evt);
            }
        });
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        menuConsultar.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem2.setText("Funcionários");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        menuConsultar.add(jMenuItem2);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem3.setText("Clientes");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        menuConsultar.add(jMenuItem3);

        jMenu4.add(menuConsultar);

        menuCadastrar.setText("Cadastrar...");

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem4.setText("Projeto");
        jMenuItem4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem4MouseClicked(evt);
            }
        });
        menuCadastrar.add(jMenuItem4);

        jMenuItem5.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem5.setText("Usuário");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        menuCadastrar.add(jMenuItem5);

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem6.setText("Mensagem");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        menuCadastrar.add(jMenuItem6);

        jMenuItem11.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_DOWN_MASK));
        jMenuItem11.setText("Adicionar usuário ao projeto...");
        jMenuItem11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem11MouseClicked(evt);
            }
        });
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        menuCadastrar.add(jMenuItem11);

        jMenu4.add(menuCadastrar);

        jMenuBar5.add(jMenu4);

        jMenu10.setText("Perfil");

        jMenuItem15.setText("Meu perfil");
        jMenuItem15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem15ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem15);

        jMenuItem16.setText("Trocar senha");
        jMenuItem16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem16ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem16);

        jMenuItem17.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        jMenuItem17.setText("Sair");
        jMenuItem17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem17ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem17);

        jMenuBar5.add(jMenu10);

        setJMenuBar(jMenuBar5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jDesktopPane1)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (this.backToUserProfile != null) {
            if (this.backToUserProfile.getTipo() > 0){
                try {
                    new PerfilFuncionario(this.backToUserProfile, this.usuario, null).setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
                }
                dispose();
            } else {
                try {
                    new PerfilCliente(this.backToUserProfile, this.usuario, null).setVisible(true);
                    dispose();
                } catch (SQLException ex) {
                    Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            try {
                new ConsultarProjeto(this.usuario).setVisible(true);
                dispose();
            } catch (SQLException ex) {
                Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void removerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerActionPerformed
        int i = JOptionPane.showConfirmDialog(null, "Deletar o cliente apagará TODAS as suas mensagens. Tem certeza em deletar o cliente "+getNome.getText()+"?");
        if (i == JOptionPane.YES_OPTION){
            new ProjetoDAO().delete(this.projeto);
            try {
                new ConsultarProjeto(this.usuario).setVisible(true);
                dispose();
            } catch (SQLException ex) {Logger.getLogger(PerfilFuncionario.class.getName()).log(Level.SEVERE, null, ex);}
        }
    }//GEN-LAST:event_removerActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
        changer = (changer == false);
        if (changer) {
            changeToEditable(getNome, changer);
            jCheckBox1.setVisible(true);
            try {
                enable(changer, jComboBox1, getEmpresa);
                jComboBox1.setSelectedItem(this.projeto.getEmpresa());
            } catch (SQLException ex) {
                Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
            }
            editar.setText("Salvar");
        } else {
            Empresa empresa = new Empresa();
            if (empresaNova) {
                String nome = (String) jComboBox1.getSelectedItem();
                empresa.setNome(nome);
                try {
                    new EmpresaDAO().add(empresa);
                    empresa.setId(new EmpresaDAO().getLastId());
                } catch (SQLException ex) {
                    Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {empresa = (Empresa) jComboBox1.getSelectedItem();}
            Projeto novoProjeto = new Projeto();
            novoProjeto.setId(this.projeto.getId());
            novoProjeto.setNome(getNome.getText());
            novoProjeto.setEmpresa(empresa);
            try {
                new ProjetoDAO().update(novoProjeto);
                JOptionPane.showMessageDialog(null, "Usuario " + novoProjeto.getNome() + " editado com sucesso! ");
                new PerfilProjetoAlternativo(novoProjeto).setVisible(true);
                dispose();
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(PerfilFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_editarActionPerformed

    private void getNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_getNomeActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint( evt.getPoint() );
        Mensagem mensagem = (Mensagem) source.getModel().getValueAt(row, 0);
        new PerfilMensagem(mensagem, this.usuario).setVisible(true);
    }//GEN-LAST:event_jTable2MouseClicked

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            new CadastrarMensagem(this.projeto, this.usuario).setVisible(true);
        } catch (ParseException ex) {
            Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        JTable source = (JTable)evt.getSource();
        int row = source.rowAtPoint( evt.getPoint() );
        Usuario usuarioSelected = (Usuario) source.getModel().getValueAt(row, 1);
        if (usuarioSelected.getTipo() > 0) {
            try {
                new PerfilFuncionario(usuarioSelected, this.usuario, this.projeto).setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
            }
            dispose();
        } else {
            try {
                new PerfilCliente(usuarioSelected, this.usuario, this.projeto).setVisible(true);
                dispose();
            } catch (SQLException ex) {
                Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jTable3MouseClicked

    private void novoParticipanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_novoParticipanteActionPerformed
        try {
            new AdicionarUsuario(this.projeto).setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_novoParticipanteActionPerformed

    private void getEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getEmpresaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_getEmpresaActionPerformed

    private void jCheckBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox1ItemStateChanged
        if (jCheckBox1.isSelected()) {
           jComboBox1.setEditable(true);
           jComboBox1.setSelectedItem("");
           empresaNova = true;
       } else {
           jComboBox1.setEditable(false);
           jComboBox1.setSelectedItem(null);
           empresaNova = false;
       }
    }//GEN-LAST:event_jCheckBox1ItemStateChanged

    private void atualizarParticipantesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarParticipantesActionPerformed
        try {
            readJTableParticipantes(this.projeto);
        } catch (SQLException ex) {
            Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_atualizarParticipantesActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        try {
            readJTableMensagens(this.projeto);
        } catch (SQLException ex) {
            Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void cadastrarMensagemSuperActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarMensagemSuperActionPerformed
        try {
            new CadastrarMensagemSUPER(this.projeto).setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cadastrarMensagemSuperActionPerformed

    private void jMenu14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu14MouseClicked
        new Home(this.usuario).setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenu14MouseClicked

    private void jMenuItem1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem1MouseClicked
        try {
            new ConsultarProjeto(this.usuario).setVisible(true);
            dispose();
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem1MouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        try {
            new ConsultarFuncionario(this.usuario).setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        try {
            new ConsultarCliente(this.usuario).setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem4MouseClicked
        try {
            new CadastrarProjeto().setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem4MouseClicked

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        try {
            new CadastrarUsuario().setVisible(true);
        } catch (SQLException | ParseException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        try {
            new CadastrarMensagemSUPER().setVisible(true);
        } catch (SQLException | ParseException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem11MouseClicked
        try {
            new AdicionarUsuario().setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem11MouseClicked

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem15ActionPerformed
        if (this.usuario.getTipo() == 0) {
            try {
                new PerfilCliente(this.usuario, true).setVisible(true);
                dispose();
            } catch (SQLException ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                new PerfilFuncionario(this.usuario, this.usuario, null).setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jMenuItem15ActionPerformed

    private void jMenuItem16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem16ActionPerformed
        new TrocarSenha(this.usuario).setVisible(true);
    }//GEN-LAST:event_jMenuItem16ActionPerformed

    private void jMenuItem17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem17ActionPerformed
        new Login().setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenuItem17ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PerfilProjetoAlternativo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new PerfilProjetoAlternativo().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton atualizarParticipantes;
    private javax.swing.JButton cadastrarMensagemSuper;
    private javax.swing.JButton editar;
    private javax.swing.JTextField getEmpresa;
    private javax.swing.JTextField getNome;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton7;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu14;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar5;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem15;
    private javax.swing.JMenuItem jMenuItem16;
    private javax.swing.JMenuItem jMenuItem17;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JMenu menuCadastrar;
    private javax.swing.JMenu menuConsultar;
    private javax.swing.JButton novoParticipante;
    private javax.swing.JButton remover;
    // End of variables declaration//GEN-END:variables
}
