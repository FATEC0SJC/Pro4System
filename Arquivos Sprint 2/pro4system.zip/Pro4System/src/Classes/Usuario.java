package Classes;

public class Usuario {
    int id;
    String nome;
    String email;
    String senha;
    String telefone;
    Empresa empresa;
    String cargo;
    int tipo;

    public Usuario(int id, String nome, String email, String senha, String telefone, Empresa empresa, String cargo, int tipo) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.empresa = empresa;
        this.cargo = cargo;
        this.tipo = tipo;
    }

    public Usuario() {
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public String getCargo() {
        return cargo;
    }

    public int getTipo() {
        return tipo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }
    
    public void setTipoFromString(String tipo) {
        if ("Cliente".equals(tipo)){
            this.tipo = 0;
        } else {if ("Suporte".equals(tipo)){
            this.tipo = 1;
        } else {this.tipo = 2;}}
    }
    
    public String getTipoString() {
        if (tipo == 0) {
            return "Cliente";
        } else {if (tipo == 1){
            return "Suporte";
        } else {
            return "Administrador";
        }} 
    }
    
    public String toString(){
        return nome;
    }     
}