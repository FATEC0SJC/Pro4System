package Classes;

public class Hora {
    int hora;
    int minuto;
    String sql;

    public Hora() {
    }

    public Hora(int hora, int minuto) {
        this.hora = hora;
        this.minuto = minuto;
    }
    
    public Hora(String sql) {
        Hora hour = fromStringToHora(sql);
        this.hora = hour.getHora();
        this.minuto = hour.getMinuto();
    }

    public int getHora() {
        return hora;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
               
    public String toSQL () {
        return this.hora+":"+this.minuto+":00";
    }
    
    public String horaToString(){
        String hora = "";
        if ((this.hora+"").length() == 1) {
            hora = "0"+this.hora;
        } else {hora = this.hora+"";}
        String minuto = "";
        if ((this.minuto+"").length() == 1) {
            minuto = "0"+this.minuto;
        } else {minuto = this.minuto+"";}
        return hora+":"+minuto;
    }
    
    public Hora fromSQL(String sql){
        char[] sqlArray = sql.toCharArray();
        Hora hour = new Hora();
        hour.setHora((Integer.parseInt(sqlArray[0]+"") * 10) + Integer.parseInt(sqlArray[1]+""));
        hour.setMinuto((Integer.parseInt(sqlArray[3]+"") * 10) + Integer.parseInt(sqlArray[4]+""));
        this.sql = sql;
        return hour;
    }
    
    public Hora fromStringToHora (String field) {
        char[] horaArray = field.toCharArray();
        int hour = (Integer.parseInt(horaArray[0]+"") * 10) + Integer.parseInt(horaArray[1]+"");
        int minute = (Integer.parseInt(horaArray[3]+"") * 10) + Integer.parseInt(horaArray[4]+"");
        return new Hora(hour, minute);
    }
    
    public Hora fromTimeStamp(String timeStamp) {
        char[] timeStampArray = timeStamp.toCharArray();
        int hour = (Integer.parseInt(timeStampArray[11]+"") * 10) + Integer.parseInt(timeStampArray[12]+"");
        int minute = (Integer.parseInt(timeStampArray[14]+"") * 10) + Integer.parseInt(timeStampArray[15]+"");
        return new Hora(hour, minute);
    }
    
    public Hora somarHoras (Hora hora1, Hora hora2) {
        int minute = hora1.getMinuto() + hora2.getMinuto();
        int hour = hora1.getHora() + hora2.getHora();
        if (minute > 59) {
            minute = 0;
            hour = hour + 1;
        }
        return new Hora(hour, minute);
    }
    
    public Hora subtrairHora (Hora hora1, Hora hora2) {            
        int minute = hora1.getMinuto() - hora2.getMinuto();
        int hour = hora1.getHora() - hora2.getHora();
        if (minute < 0) {
            minute = minute + 60;
            hour = hour - 1;
        }
        return new Hora(hour, minute);
    }
    
    public String asSQL () {
        return sql;
    }
    
    @Override
    public String toString(){
        return horaToString();
    }
}
