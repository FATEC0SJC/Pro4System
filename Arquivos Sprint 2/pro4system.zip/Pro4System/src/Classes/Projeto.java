package Classes;

import java.util.List;



public class Projeto {
    int id;
    String nome;
    List<Usuario> participantes;
    Empresa empresa;

    public Projeto() {
    }

    public Projeto(int id, String nome, List<Usuario> participantes, Empresa empresa) {
        this.id = id;
        this.nome = nome;
        this.participantes = participantes;
        this.empresa = empresa;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public List<Usuario> getParticipantes() {
        return participantes;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setParticipantes(List<Usuario> participantes) {
        this.participantes = participantes;
    }
    
    public void addParticipante (Usuario participante) {
        participantes.add(participante);
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }
     
    public String toString(){
        return nome;
    }    
}
