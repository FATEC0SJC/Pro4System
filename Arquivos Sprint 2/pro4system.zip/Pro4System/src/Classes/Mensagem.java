package Classes;

public class Mensagem {
    int id;
    String titulo;
    String texto;
    Projeto projeto;
    Usuario remetente;
    int tipo;
    Dia data;
    Hora hora;

    public Mensagem(int id, String titulo, String texto, Projeto projeto, Usuario remetente, int tipo, Dia data, Hora hora) {
        this.id = id;
        this.titulo = titulo;
        this.texto = texto;
        this.projeto = projeto;
        this.remetente = remetente;
        this.tipo = tipo;
        this.data = data;
        this.hora = hora;
    }

    public Mensagem() {
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getTexto() {
        return texto;
    }

    public Projeto getProjeto() {
        return projeto;
    }

    public Usuario getRemetente() {
        return remetente;
    }

    public int getTipo() {
        return tipo;
    }
    
    public Dia getData() {
        return data;
    }

    public Hora getHora() {
        return hora;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public void setProjeto(Projeto projeto) {
        this.projeto = projeto;
    }

    public void setRemetente(Usuario remetente) {
        this.remetente = remetente;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void setData(Dia data) {
        this.data = data;
    }

    public void setHora(Hora hora) {
        this.hora = hora;
    }
    
    public String tipoToString () {
        if (tipo == 0) {return "Sistema";} else {
            if (tipo == 1) {return "Email";} else {
                if (tipo == 2) {return "Whatsapp";} else {
                    return "SMS";
                }
            }
        }   
    }
    
    public void setTipoFromString (String tipo) {
        if (tipo.equals("Sistema")) {this.tipo = 0;}
        else if (tipo.equals("Email")) {this.tipo = 1;}
        else if (tipo.equals("Whatsapp")) {this.tipo = 2;}
        else {this.tipo = 3;} //se tipo == sms
    }
    
    @Override
    public String toString(){
        return titulo;
    }
}
