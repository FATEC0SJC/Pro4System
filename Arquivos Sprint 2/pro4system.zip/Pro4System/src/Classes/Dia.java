package Classes;

public final class Dia {
    int dia;
    int mes;
    int ano;

    public Dia() {
    }

    public Dia(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }
    
    public Dia(String sql) {
        Dia day = fromSQL(sql);
        this.dia = day.getDia();
        this.mes = day.getMes();
        this.ano = day.getAno();
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAno() {
        return ano;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
    public String toSQL () {
        String mesT;
        String diaT;
        if (this.mes < 10) {mesT = "0"+this.mes;} else {mesT = this.mes+"";}
        if (this.dia < 10) {diaT = "0"+this.dia;} else {diaT = this.dia+"";}
        return this.ano+""+mesT+diaT;
    }
    
    public String dataToString() {
        String dia = "";
        if (this.dia+"".length() == 1) {
            dia = "0"+this.dia+"";
        } else {dia = this.dia+"";}
        String mes = "";
        if (this.mes+"".length() == 1) {
            mes = "0"+this.mes+"";
        } else {mes = this.mes+"";}
        return dia+"/"+mes+"/"+this.ano;
    }
    
    public Dia fromSQL (String sql) {
        char[] sqlArray = sql.toCharArray();
        //20220506
        int year = (Integer.parseInt(sqlArray[0]+"") * 1000) + (Integer.parseInt(sqlArray[1]+"") * 100) + (Integer.parseInt(""+sqlArray[2]) * 10) + Integer.parseInt(""+sqlArray[3]);
        int month = (Integer.parseInt(""+sqlArray[5]) * 10) + Integer.parseInt(""+sqlArray[6]);
        int day = (Integer.parseInt(""+sqlArray[8]) * 10) + Integer.parseInt(""+sqlArray[9]);
        return new Dia(day, month, year);
    }
    
    public Dia fromFieldToDia (String field) {
        char[] diaArray = field.toCharArray();
        int day = (Integer.parseInt(diaArray[0]+"") * 10) + Integer.parseInt(diaArray[1]+"");
        int month = (Integer.parseInt(diaArray[3]+"") * 10) + Integer.parseInt(diaArray[4]+"");
        int year = (Integer.parseInt(diaArray[6]+"") * 1000) + (Integer.parseInt(diaArray[7]+"") * 100) + (Integer.parseInt(diaArray[8]+"") * 10) + Integer.parseInt(diaArray[8]+"");
        return new Dia(day, month, year);
    }
    
    public boolean isTheSame(Dia data) {
        boolean vDia = this.dia == data.getDia();
        boolean vMes = this.mes == data.getMes();
        boolean vAno = this.ano == data.getAno();
        return vDia && vMes && vAno;
    }
    
    public Dia subtrairData(Dia dataMaior, Dia dataMenor) {
        int day = dataMaior.getDia() - dataMenor.getDia();
        int month = dataMaior.getMes() - dataMenor.getMes();
        int year = dataMaior.getAno() - dataMenor.getAno();
        if (month < 0) {
            year = year - 1;
            month = month + 12;
        }
        if (day < 0) {
            month = month - 1;
            day = day + 30;
        }
        
        return new Dia(day, month ,year);
    }
    
    @Override
    public String toString(){
        return dataToString();
    }
}
