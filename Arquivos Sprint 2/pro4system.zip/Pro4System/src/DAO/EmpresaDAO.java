package DAO;

import Classes.Empresa;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmpresaDAO {
    private Connection connection;
    
    public EmpresaDAO (){
        this.connection = new ConnectionFactory().getConnection();
    }
    
    public void add(Empresa empresa) throws SQLException{
        String sql = "INSERT INTO empresas (nome) VALUES (?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, empresa.getNome());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    
    public List<Empresa> read() throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM empresas");
        rs = stmt.executeQuery();
        
        List<Empresa> projetos = new ArrayList<Empresa>();
        while(rs.next()) { 
            Empresa empresa = new Empresa();
            empresa.setId(rs.getInt("id"));
            empresa.setNome(rs.getString("nome"));
            projetos.add(empresa);
        }
        return projetos;
    }
    
    public Empresa searchById(int id) throws SQLException{
        PreparedStatement stmt;
        ResultSet rs;
            stmt = connection.prepareStatement("SELECT * FROM empresas WHERE id = ?");
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            Empresa empresa = new Empresa();
        while(rs.next()) {
            empresa.setId(rs.getInt("id"));
            empresa.setNome(rs.getString("nome"));
        }
        return empresa;
    }
    
    public void update(Empresa empresa) throws SQLException{
        String command0 = "SET foreign_key_checks = 0";
        String command1 = "SET foreign_key_checks = 1";
            String sql = "UPDATE empresas SET nome = ? WHERE id = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, empresa.getNome());
                stmt.setInt(2, empresa.getId());
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    
    public void delete(Empresa empresa) {
        String command0 = "set SQL_SAFE_UPDATES = 0";
        String command1 = "set SQL_SAFE_UPDATES = 1";
        String sql = "DELETE FROM empresas WHERE id = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setInt(1, empresa.getId());
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
    
    public int getLastId () throws SQLException {
        String sql = "SELECT MAX(id) as id FROM empresas";
        PreparedStatement stmt;
        ResultSet rs;
            stmt = connection.prepareStatement(sql);
            rs = stmt.executeQuery();
            Empresa empresa = new Empresa();
        while(rs.next()) {
            empresa.setId(rs.getInt("id"));
        }
        return empresa.getId();
    }
}
