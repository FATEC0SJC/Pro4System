package DAO;

import Classes.Empresa;
import Classes.Projeto;
import Classes.Usuario;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProjetoDAO {
    private Connection connection;
    
    public ProjetoDAO (){
        this.connection = new ConnectionFactory().getConnection();
    }
    
    //adicionar novo projeto
    public void add(Projeto projeto) throws SQLException{
        String sql = "INSERT INTO projetos (nome, empresa) VALUES (?, ?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, projeto.getNome());
                stmt.setInt(2, projeto.getEmpresa().getId());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    
    //consultar projetos
    public List<Projeto> read() throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM projetos");
        rs = stmt.executeQuery();
        
        List<Projeto> projetos = new ArrayList<Projeto>();
        while(rs.next()) { 
            Empresa empresa = new EmpresaDAO().searchById(rs.getInt("empresa"));
            Projeto projeto = new Projeto();
            projeto.setId(rs.getInt("id"));
            projeto.setNome(rs.getString("nome"));
            projeto.setEmpresa(empresa);
            projeto.setParticipantes(readUsers(projeto));
            projetos.add(projeto);
        }
        return projetos;
    }
    
    public List<Projeto> readExcept(Usuario usuario) throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM projetos");
        rs = stmt.executeQuery();
        
        List<Projeto> projetos = new ArrayList<Projeto>();
        while(rs.next()) {
            boolean verify = false;
            Projeto projeto = new Projeto();
            projeto.setParticipantes(readUsers(projeto));
            Empresa empresa = new EmpresaDAO().searchById(rs.getInt("empresa"));
            projeto.setEmpresa(empresa);
            projeto.setId(rs.getInt("id"));
            projeto.setNome(rs.getString("nome"));
            if (!(projeto.getParticipantes().contains(usuario))) {
                projetos.add(projeto);
            }
        }
        return projetos;
    }
    
    //filtrar proejtos na consulta
    public List<Projeto> filter(String nome, Empresa empresa, Usuario participante) throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
        
        if (empresa != null) {
            stmt = connection.prepareStatement("SELECT * FROM projetos WHERE nome LIKE ? AND empresa = ?");
            stmt.setInt(2, empresa.getId());
        } else {
            stmt = connection.prepareStatement("SELECT * FROM projetos WHERE nome LIKE ?");
        }
            stmt.setString(1, "%"+nome+"%");
            rs = stmt.executeQuery();
        
        List<Projeto> projetos = new ArrayList<Projeto>();
        while(rs.next()) { 
            Empresa empresaX = new EmpresaDAO().searchById(rs.getInt("empresa"));
            Projeto projeto = new Projeto();
            projeto.setId(rs.getInt("id"));
            projeto.setNome(rs.getString("nome"));
            projeto.setEmpresa(empresaX);
            projeto.setParticipantes(readUsers(projeto));
            if (participante != null) {
                if (projeto.getParticipantes().contains(participante)) {
                    projetos.add(projeto);
                }
            } else {
                projetos.add(projeto);
            }
        }
        return projetos;
    }
    
    
    
    public List<Projeto> filterByUsuario(Usuario participante) throws SQLException{
        PreparedStatement stmt;
        ResultSet rs;
            stmt = connection.prepareStatement("SELECT * FROM participantes WHERE idUsuario = ?");
            stmt.setInt(1, participante.getId());
        rs = stmt.executeQuery();
        
        List<Projeto> projetos = new ArrayList<Projeto>();
        while(rs.next()) { 
            Projeto projeto = new ProjetoDAO().searchById(rs.getInt("idProjeto"));
            projetos.add(projeto);
        }
        return projetos;
    }
    
    //encontrar projeto por id
    public Projeto searchById(int id) throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
            stmt = connection.prepareStatement("SELECT * FROM projetos WHERE id = ?");
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            Projeto projeto = new Projeto();
        while(rs.next()) {
            Empresa empresaX = new EmpresaDAO().searchById(rs.getInt("empresa"));
            projeto.setId(rs.getInt("id"));
            projeto.setNome(rs.getString("nome"));
            projeto.setEmpresa(empresaX);
            projeto.setParticipantes(readUsers(projeto));
        }
        return projeto;
    }
    
    //adicionar participante
    public void addUser(Usuario usuario, Projeto projeto) throws SQLException{
        String sql = "INSERT INTO participantes (idProjeto, idUsuario) VALUES (?, ?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setInt(1, projeto.getId());
                stmt.setInt(2, usuario.getId());
            stmt.execute();
            stmt.close();
            if (usuario.getTipo() > 0) {
                String sql2 = "INSERT INTO relatorio (idProjeto, idUsuario, interacoes, tempoRespostaTotal) VALUES (?, ?, ?, ?)";            
                stmt = connection.prepareStatement(sql2);
                    stmt.setInt(1, projeto.getId());
                    stmt.setInt(2, usuario.getId());
                    stmt.setInt(3, 0);
                    stmt.setInt(4,0);
                stmt.execute();
                stmt.close();  
            }
        }
                
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    //listar participantes
    public List<Usuario> readUsers(Projeto projeto) throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM participantes WHERE idProjeto = ?");
        stmt.setInt(1, projeto.getId());
        rs = stmt.executeQuery();
        
        List<Usuario> participantes = new ArrayList<Usuario>();
        while(rs.next()) {
            Usuario participante = new UsuarioDAO().searchById(rs.getInt("idUsuario"));
            participantes.add(participante);
        }
        return participantes;
    }
    
    public List<Integer> readUsersId(Projeto projeto) throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM participantes WHERE idProjeto = ?");
        stmt.setInt(1, projeto.getId());
        rs = stmt.executeQuery();
        
        List<Integer> participantes = new ArrayList<Integer>();
        while(rs.next()) {
            participantes.add(rs.getInt("idUsuario"));
        }
        return participantes;
    }
    
    
    
    //remover participante
    public void deleteUser(Projeto projeto, Usuario usuario) {
        String command0 = "set SQL_SAFE_UPDATES = 0";
        String command1 = "set SQL_SAFE_UPDATES = 1";
        String sql = "DELETE FROM participantes WHERE idProjeto = ? and idUsuario = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setInt(1, projeto.getId());
                stmt.setInt(2, usuario.getId());
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
    
    //editar projeto
    public void update(Projeto projeto) throws SQLException{
        String command0 = "SET foreign_key_checks = 0";
        String command1 = "SET foreign_key_checks = 1";
            String sql = "UPDATE projetos SET nome = ?, empresa = ? WHERE id = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, projeto.getNome());
                stmt.setInt(2, projeto.getEmpresa().getId());
                stmt.setInt(3, projeto.getId());
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    
    //deletar projeto
    public void delete(Projeto projeto) {
        String command0 = "set SQL_SAFE_UPDATES = 0";
        String command1 = "set SQL_SAFE_UPDATES = 1";
        String sql = "DELETE FROM projetos WHERE id = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setInt(1, projeto.getId());
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
}
