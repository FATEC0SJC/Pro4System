package DAO;

import Classes.Empresa;
import Classes.Usuario;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private Connection connection;
    
    public UsuarioDAO(){
        this.connection = new ConnectionFactory().getConnection();
    }
    
    //adicionar novo usuario
    public void add(Usuario usuario) throws SQLException{
        String sql = "INSERT INTO usuarios (nome, email, senha, telefone, empresa, cargo, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, usuario.getNome());
                stmt.setString(2, usuario.getEmail());
                stmt.setString(3, usuario.getSenha());
                stmt.setString(4, usuario.getTelefone());
                stmt.setInt(5, usuario.getEmpresa().getId());
                stmt.setString(6, usuario.getCargo());
                stmt.setInt(7, usuario.getTipo());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    
    //consultar usuarios
    public List<Usuario> read() throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM usuarios");
        rs = stmt.executeQuery();
        
        List<Usuario> usuarios = new ArrayList<Usuario>();
        while(rs.next()) {
            Usuario usuario = new Usuario();
            usuario.setId(rs.getInt("id"));
            usuario.setNome(rs.getString("nome"));
            usuario.setEmpresa(new EmpresaDAO().searchById((rs.getInt("empresa"))));
            usuario.setTelefone(rs.getString("telefone"));
            usuario.setEmail(rs.getString("email"));
            usuario.setCargo(rs.getString("cargo"));
            usuario.setSenha(rs.getString("senha"));
            usuario.setTipo(rs.getInt("tipo"));
            usuarios.add(usuario);
        }
        return usuarios;
    }
    
    //filtrar usuarios na consulta
    public List<Usuario> filter(String nome, Empresa empresa, String cargo, int tipo) throws SQLException{
        
        PreparedStatement stmt;
        ResultSet rs;
        String sql;
        String sql1 = "SELECT * FROM usuarios WHERE nome LIKE ?  AND cargo LIKE ? AND tipo = ? AND empresa = ?";
        String sql2 = "SELECT * FROM usuarios WHERE nome LIKE ? AND cargo LIKE ? AND tipo = ?";
        if (empresa != null) {sql = sql1;} else {sql = sql2;}
        stmt = connection.prepareStatement(sql);
        stmt.setString(1, "%"+nome+"%");
        stmt.setString(2, "%"+cargo+"%");
        stmt.setInt(3, tipo);
        if (empresa != null) {stmt.setInt(4, empresa.getId());}
        rs = stmt.executeQuery();
        
        List<Usuario> usuarios = new ArrayList<Usuario>();
        while(rs.next()) {
            Usuario usuario = new Usuario();
            usuario.setId(rs.getInt("id"));
            usuario.setNome(rs.getString("nome"));
            usuario.setEmpresa(new EmpresaDAO().searchById((rs.getInt("empresa"))));
            usuario.setTelefone(rs.getString("telefone"));
            usuario.setEmail(rs.getString("email"));
            usuario.setCargo(rs.getString("cargo"));
            usuario.setSenha(rs.getString("senha"));
            usuario.setTipo(rs.getInt("tipo"));
            usuarios.add(usuario);
        }
        return usuarios;
    }
    
    //encontrar usuario com id
    public Usuario searchById(int id) throws SQLException{
        PreparedStatement stmt;
        ResultSet rs;
       
        stmt = connection.prepareStatement("SELECT * FROM usuarios WHERE id = ?");
        stmt.setInt(1, id);
        rs = stmt.executeQuery();
        
        Usuario usuario = new Usuario();
        while(rs.next()) {
            usuario.setId(rs.getInt("id"));
            usuario.setNome(rs.getString("nome"));
            usuario.setEmpresa(new EmpresaDAO().searchById((rs.getInt("empresa"))));
            usuario.setTelefone(rs.getString("telefone"));
            usuario.setEmail(rs.getString("email"));
            usuario.setCargo(rs.getString("cargo"));
            usuario.setSenha(rs.getString("senha"));
            usuario.setTipo(rs.getInt("tipo"));
        }
        return usuario;
    }
    
    public Usuario login(String email, String senha) throws SQLException{
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM usuarios WHERE email = ? AND senha = ?");
            stmt.setString(1, email);
            stmt.setString(2, senha);
        ResultSet rs = stmt.executeQuery();
        Usuario usuario = new Usuario();
        while(rs.next()) {
            usuario.setId(rs.getInt("id"));
            usuario.setNome(rs.getString("nome"));
            usuario.setEmpresa(new EmpresaDAO().searchById((rs.getInt("empresa"))));
            usuario.setTelefone(rs.getString("telefone"));
            usuario.setEmail(rs.getString("email"));
            usuario.setCargo(rs.getString("cargo"));
            usuario.setSenha(rs.getString("senha"));
            usuario.setTipo(rs.getInt("tipo"));
        }
        return usuario;
    }
    
    //editar usuario
    public void update(Usuario usuario) throws SQLException{
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE usuarios SET nome = ?, empresa = ?, cargo = ?, telefone = ?, email = ?, tipo = ?, senha = ? WHERE id = ?");
                stmt.setString(1, usuario.getNome());
                stmt.setInt(2, usuario.getEmpresa().getId());
                stmt.setString(3, usuario.getCargo());
                stmt.setString(4, usuario.getTelefone());
                stmt.setString(5, usuario.getEmail());
                stmt.setInt(6, usuario.getTipo());
                stmt.setString(7, usuario.getSenha());
                stmt.setInt(8, usuario.getId());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }      
    }
    
    //deletar usuario
    public void delete(int id) {
        String command0 = "set SQL_SAFE_UPDATES = 0";
        String command1 = "set SQL_SAFE_UPDATES = 1";
        String sql = "DELETE FROM usuarios WHERE id = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
}
