package DAO;

import Classes.Dia;
import Classes.Hora;
import Classes.Mensagem;
import Classes.Projeto;
import Classes.Usuario;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import static java.util.Calendar.MONTH;

public class MensagemDAO {

    private Connection connection;

    public MensagemDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }

    public int getInteracao(Projeto projeto, Usuario usuario) throws SQLException {
        String cmdInteracao = "SELECT * FROM relatorio WHERE idUsuario = ? AND idProjeto = ?";
        PreparedStatement interacao = connection.prepareStatement(cmdInteracao);
        interacao.setInt(1, usuario.getId());
        interacao.setInt(2, projeto.getId());
        ResultSet inter = interacao.executeQuery();
        int interacaoUsuario = 0;
        while (inter.next()) {
            interacaoUsuario = inter.getInt("interacoes");
        }
        return interacaoUsuario;
    }
    
    public int getTempoTotal(Projeto projeto, Usuario usuario) throws SQLException {
        String cmdInteracao = "SELECT * FROM relatorio WHERE idUsuario = ? AND idProjeto = ?";
        PreparedStatement interacao = connection.prepareStatement(cmdInteracao);
        interacao.setInt(1, usuario.getId());
        interacao.setInt(2, projeto.getId());
        ResultSet inter = interacao.executeQuery();
        int tempoRespostaTotal = 0;
        while (inter.next()) {
            tempoRespostaTotal = inter.getInt("tempoRespostaTotal");
        }
        return tempoRespostaTotal;
    }
    
    public int getTempoTotalFromUser(Usuario usuario) throws SQLException {
        String cmdInteracao = "SELECT * FROM relatorio WHERE idUsuario = ?";
        PreparedStatement interacao = connection.prepareStatement(cmdInteracao);
        interacao.setInt(1, usuario.getId());
        ResultSet inter = interacao.executeQuery();
        int tempos = 0;
        while (inter.next()) {
            tempos = tempos + inter.getInt("tempoRespostaTotal");
        }
        return tempos;
    }
    
    public int getInteracoes(Usuario usuario) throws SQLException {
        String cmdInteracao = "SELECT * FROM relatorio WHERE idUsuario = ?";
        PreparedStatement interacao = connection.prepareStatement(cmdInteracao);
        interacao.setInt(1, usuario.getId());
        ResultSet inter = interacao.executeQuery();
        int interacoes = 0;
        while (inter.next()) {
            interacoes = interacoes + inter.getInt("tempoRespostaTotal");
        }
        return interacoes;
    }

    private Mensagem getLastMessageCliente(Projeto projeto2) throws SQLException {
        PreparedStatement stmt;
        ResultSet rs;

        stmt = connection.prepareStatement("SELECT dia, hora, remetente FROM mensagens WHERE projeto = ? ORDER BY dia DESC, hora DESC");
        stmt.setInt(1, projeto2.getId());
        rs = stmt.executeQuery();

        Mensagem mensagem = new Mensagem();
        while (rs.next()) {
            Usuario usuario = new UsuarioDAO().searchById(rs.getInt("remetente"));
            if (usuario.getTipo() == 0) {
                mensagem.setData(new Dia(rs.getString("dia")));
                mensagem.setHora(new Hora(rs.getString("hora")));
                break;
            }
        }
        return mensagem;
    }

    private int getTempo(Projeto projeto, Usuario usuario) throws SQLException {
        String cmdInteracao = "SELECT * FROM relatorio WHERE idUsuario = ? AND idProjeto = ?";
        PreparedStatement interacao = connection.prepareStatement(cmdInteracao);
        interacao.setInt(1, usuario.getId());
        interacao.setInt(2, projeto.getId());
        ResultSet inter = interacao.executeQuery();
        int tempoRespostaTotal = 0;
        while (inter.next()) {
            tempoRespostaTotal = inter.getInt("tempoRespostaTotal");
        }
        return tempoRespostaTotal;
    }

    public void add(Mensagem mensagem) throws SQLException {
        String sql = "INSERT INTO mensagens (titulo, texto, remetente, projeto, tipo, dia, hora) values (?, ?, ?, ?, ?, ?, ?)";
        try {//registrar mensagem
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, mensagem.getTitulo());
            stmt.setString(2, mensagem.getTexto());
            stmt.setInt(3, mensagem.getRemetente().getId());
            stmt.setInt(4, mensagem.getProjeto().getId());
            stmt.setInt(5, mensagem.getTipo());
            stmt.setString(6, mensagem.getData().toSQL());
            stmt.setString(7, mensagem.getHora().toSQL());
            stmt.execute();
            stmt.close();
            if (mensagem.getRemetente().getTipo() > 0) {
                updateRelatorio(mensagem);
            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
    
    private String to2Digits(int n) {
        if (n < 10) {
            return "0"+n;
        } else {
            return n+"";
        }      
    }
    
    public void updateRelatorio(Mensagem mensagem) throws SQLException {
        PreparedStatement stmt;
        
        Projeto projeto = mensagem.getProjeto();
        Usuario usuario = mensagem.getRemetente();
        
        //somando interação
        int interacao = getInteracao(projeto, usuario) + 1;
        
        //somando tempo total mensagem
        //calculando tempo de resposta da última mensagem
        Mensagem mensagemCliente = getLastMessageCliente(projeto);
            String mesMensagem = to2Digits(mensagem.getData().getMes());
            String mesCliente = to2Digits(mensagemCliente.getData().getMes());
            String diaMensagem = to2Digits(mensagem.getData().getDia());
            String diaCliente = to2Digits(mensagemCliente.getData().getDia());
            String horaMensagem = to2Digits(mensagem.getHora().getHora());
            String horaCliente = to2Digits(mensagemCliente.getHora().getHora());
            String minutoMensagem = to2Digits(mensagem.getHora().getMinuto());
            String minutoCliente = to2Digits(mensagemCliente.getHora().getMinuto());
            System.out.println(mensagemCliente.getHora().getHora());
            LocalDate dateMensagem = LocalDate.parse(mensagem.getData().getAno()+"-"+mesMensagem+"-"+diaMensagem);
            LocalDate dateCliente = LocalDate.parse(mensagemCliente.getData().getAno()+"-"+mesCliente+"-"+diaCliente);
            int diferencaDias = (int) ChronoUnit.DAYS.between(dateMensagem, dateCliente);
            LocalTime hourMensagem = LocalTime.parse(horaMensagem+":"+minutoMensagem+":00");
            LocalTime hourCliente = LocalTime.parse(horaCliente+":"+minutoCliente+":00");
            int diferencaMinutos = (int) ChronoUnit.MINUTES.between(hourCliente, hourMensagem);
            diferencaMinutos = diferencaMinutos + (diferencaDias * 24);
            
        //pegando tempo de resposta total do banco de dados e somando    
        int horaTotal = Integer.parseInt(getTempo(projeto, usuario)+"");
        //antes: int horaTotal = getTempo(projeto, usuario);
        horaTotal = horaTotal + diferencaMinutos;
        
        String command0 = "set SQL_SAFE_UPDATES = 0";
        stmt = connection.prepareStatement(command0);
            stmt.execute();
            stmt.close();
        String cmdGetRelatorio = "UPDATE relatorio SET interacoes = ?, tempoRespostaTotal = ? WHERE idUsuario = ? AND idProjeto = ?";
        stmt = connection.prepareStatement(cmdGetRelatorio);
            stmt.setInt(1, interacao);
            stmt.setInt(2, horaTotal);
            stmt.setInt(3, usuario.getId());
            stmt.setInt(4, projeto.getId());
            stmt.execute();
            stmt.close();
        String command1 = "set SQL_SAFE_UPDATES = 1";
        stmt = connection.prepareStatement(command1);
            stmt.execute();
            stmt.close();
    }

    public List<Mensagem> read() throws SQLException {
        PreparedStatement stmt;
        ResultSet rs;

        stmt = connection.prepareStatement("SELECT * FROM mensagens");
        rs = stmt.executeQuery();

        List<Mensagem> mensagens = new ArrayList<Mensagem>();
        while (rs.next()) {
            Projeto projeto = new ProjetoDAO().searchById(rs.getInt("projeto"));
            Usuario usuario = new UsuarioDAO().searchById(rs.getInt("remetente"));
            Mensagem mensagem = new Mensagem();
            mensagem.setId(rs.getInt("id"));
            mensagem.setRemetente(usuario);
            mensagem.setProjeto(projeto);
            mensagem.setTitulo(rs.getString("titulo"));
            mensagem.setTexto(rs.getString("texto"));
            mensagem.setTipo(rs.getInt("tipo"));
            mensagem.setData(new Dia(rs.getString("dia")));
            mensagem.setHora(new Hora(rs.getString("hora")));
            mensagens.add(mensagem);
        }
        return mensagens;
    }

    public List<Mensagem> filterByProject(Projeto projeto) throws SQLException {
        PreparedStatement stmt;
        ResultSet rs;
        stmt = connection.prepareStatement("SELECT * FROM mensagens WHERE projeto = ?");
        stmt.setInt(1, projeto.getId());
        rs = stmt.executeQuery();

        List<Mensagem> mensagens = new ArrayList<Mensagem>();
        while (rs.next()) {
            Usuario usuario = new UsuarioDAO().searchById(rs.getInt("remetente"));
            Mensagem mensagem = new Mensagem();
            mensagem.setId(rs.getInt("id"));
            mensagem.setRemetente(usuario);
            mensagem.setProjeto(projeto);
            mensagem.setTitulo(rs.getString("titulo"));
            mensagem.setTexto(rs.getString("texto"));
            mensagem.setTipo(rs.getInt("tipo"));
            mensagem.setData(new Dia().fromSQL(rs.getString("dia")));
            mensagem.setHora(new Hora().fromStringToHora(rs.getString("hora")));
            mensagens.add(mensagem);
        }
        return mensagens;
    }

    public List<Mensagem> filterByRemetente(Usuario usuario) throws SQLException {
        PreparedStatement stmt;
        ResultSet rs;
        stmt = connection.prepareStatement("SELECT * FROM mensagens WHERE remetente = ?");
        stmt.setInt(1, usuario.getId());
        rs = stmt.executeQuery();

        List<Mensagem> mensagens = new ArrayList<Mensagem>();
        while (rs.next()) {
            Projeto projeto = new ProjetoDAO().searchById(rs.getInt("projeto"));
            Mensagem mensagem = new Mensagem();
            mensagem.setRemetente(usuario);
            mensagem.setId(rs.getInt("id"));
            mensagem.setProjeto(projeto);
            mensagem.setTitulo(rs.getString("titulo"));
            mensagem.setTexto(rs.getString("texto"));
            mensagem.setTipo(rs.getInt("tipo"));
            mensagem.setData(new Dia(rs.getString("dia")));
            mensagem.setHora(new Hora().fromSQL(rs.getString("hora")));
            mensagens.add(mensagem);
        }
        return mensagens;
    }

    public void delete(Mensagem mensagem) {
        String command0 = "set SQL_SAFE_UPDATES = 0";
        String command1 = "set SQL_SAFE_UPDATES = 1";
        String sql = "DELETE FROM mensagem WHERE id = ?";
        try {
            PreparedStatement cm0 = connection.prepareStatement(command0);
            cm0.execute();
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, mensagem.getId());
            stmt.execute();
            stmt.close();
            PreparedStatement cm1 = connection.prepareStatement(command1);
            cm1.execute();
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
}
